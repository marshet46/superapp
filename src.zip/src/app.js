const express = require('express');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const cors = require('cors');
const path = require('path');
require('dotenv').config();
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./apidocs/app.json'); // Import your Swagger JSON

  

// Import models to initialize them
const db = require('./models/appModel');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(helmet());

// Serve static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Serve Swagger UI
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Routes import
const appRoutes = require('./routes/appRoute');

// Route definition
app.use('/api', appRoutes);

// Global error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled Error:', err);
    res.status(500).json({ error: `Internal Server Error: the Error is -> ${err}` });
});

// Start the server and sync database
db.sequelize.sync().then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
});

// Handle process termination gracefully
process.on('SIGINT', () => {
    console.log('Closing server...');
    process.exit(0);
});
